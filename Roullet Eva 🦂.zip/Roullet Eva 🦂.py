import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
import random
import asyncio
from datetime import datetime, timedelta
import json
import os
import re

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

BOT_USERNAME = "xEvaxBot"
TOKEN = "7985836024:AAHDJBoV68FBwdtOZub4zulLdvbeY9IPJZY"

# ضع الآيدي الخاص بك هنا
ADMIN_ID = 7804017901

DATA_FILE = 'bot_data.json'

user_data = {}
channel_data = {}
roulette_data = {}
participant_data = {}
reminder_users = set()
roulette_status = {}
blocked_users = set()
all_users = set()
bot_active = True
join_notifications = True
broadcast_channel_id = None
broadcast_channel_username = None
forced_channels = []
user_stats = {}
withdrawal_cooldown = {}
user_action_history = {}

def save_data():
    try:
        data = {
            'user_data': user_data,
            'channel_data': channel_data,
            'roulette_data': {k: {**v, 'created_at': v['created_at'].isoformat() if isinstance(v.get('created_at'), datetime) else str(v.get('created_at', ''))} for k, v in roulette_data.items()},
            'participant_data': participant_data,
            'reminder_users': list(reminder_users),
            'roulette_status': roulette_status,
            'blocked_users': list(blocked_users),
            'all_users': list(all_users),
            'bot_active': bot_active,
            'join_notifications': join_notifications,
            'broadcast_channel_id': broadcast_channel_id,
            'broadcast_channel_username': broadcast_channel_username,
            'forced_channels': forced_channels,
            'user_stats': user_stats,
            'withdrawal_cooldown': {k: v.isoformat() if isinstance(v, datetime) else str(v) for k, v in withdrawal_cooldown.items()},
            'user_action_history': user_action_history
        }
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f'Error saving data: {e}')

def load_data():
    global user_data, channel_data, roulette_data, participant_data, reminder_users
    global roulette_status, blocked_users, all_users, bot_active, join_notifications
    global broadcast_channel_id, broadcast_channel_username, forced_channels
    global user_stats, withdrawal_cooldown, user_action_history
    
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                user_data = data.get('user_data', {})
                channel_data = data.get('channel_data', {})
                roulette_data = data.get('roulette_data', {})
                participant_data = data.get('participant_data', {})
                reminder_users = set(data.get('reminder_users', []))
                roulette_status = data.get('roulette_status', {})
                blocked_users = set(data.get('blocked_users', []))
                all_users = set(data.get('all_users', []))
                bot_active = data.get('bot_active', True)
                join_notifications = data.get('join_notifications', True)
                broadcast_channel_id = data.get('broadcast_channel_id')
                broadcast_channel_username = data.get('broadcast_channel_username')
                forced_channels = data.get('forced_channels', [])
                user_stats = data.get('user_stats', {})
                withdrawal_cooldown_raw = data.get('withdrawal_cooldown', {})
                withdrawal_cooldown = {}
                for k, v in withdrawal_cooldown_raw.items():
                    try:
                        withdrawal_cooldown[k] = datetime.fromisoformat(v) if v else None
                    except:
                        withdrawal_cooldown[k] = None
                user_action_history = data.get('user_action_history', {})
    except Exception as e:
        logger.error(f'Error loading data: {e}')

def get_user_data(user_id):
    if user_id not in user_data:
        user_data[user_id] = {
            'channels': [],
            'state': None,
            'temp_data': {}
        }
    return user_data[user_id]

def get_user_stats(user_id):
    user_id_str = str(user_id)
    if user_id_str not in user_stats:
        user_stats[user_id_str] = {
            'created_giveaways': 0,
            'participated_giveaways': 0,
            'wins': 0
        }
    return user_stats[user_id_str]

def update_user_stats(user_id, stat_type, increment=1):
    stats = get_user_stats(user_id)
    if stat_type in stats:
        stats[stat_type] += increment
        save_data()

def is_triple_username(username):
    """التحقق من أن اليوزر ثلاثي (يحتوي على شرطتين و3 أحرف/أرقام فقط)"""
    if not username:
        return False
    # نمط اليوزر الثلاثي: حرف/رقم _ حرف/رقم _ حرف/رقم
    pattern = r'^[a-zA-Z0-9]_[a-zA-Z0-9]_[a-zA-Z0-9]$'
    return bool(re.match(pattern, username))

async def check_forced_channels(user_id, context):
    """التحقق من الاشتراك في القنوات الإجبارية"""
    if not forced_channels:
        return True, None
    
    not_subscribed = []
    for channel_info in forced_channels:
        try:
            channel_id = channel_info.get('id')
            member = await context.bot.get_chat_member(channel_id, user_id)
            if member.status not in ['member', 'administrator', 'creator']:
                not_subscribed.append(channel_info)
        except Exception as e:
            logger.error(f'Error checking forced channel: {e}')
            not_subscribed.append(channel_info)
    
    if not_subscribed:
        return False, not_subscribed
    return True, None

async def check_user_is_admin(context, channel_username, user_id):
    """التحقق من أن المستخدم أدمن في القناة"""
    try:
        chat = await context.bot.get_chat(f'@{channel_username}')
        member = await context.bot.get_chat_member(chat.id, user_id)
        return member.status in ['administrator', 'creator']
    except Exception as e:
        logger.error(f'Error checking admin status: {e}')
        return False

def get_footer_text():
    """إنشاء نص التذييل مع الروابط بدون أيقونات"""
    footer = f'<b><a href="tg://resolve?domain={BOT_USERNAME}">‌روليت إيفا</a></b>'
    
    if broadcast_channel_username:
        footer += ' <b>-</b> '
        footer += f'<b><a href="tg://resolve?domain={broadcast_channel_username}">‌السحوبات</a></b>'
    
    return footer

def check_withdrawal_abuse(user_id, roulette_id):
    """التحقق من محاولة التلاعب"""
    user_id_str = str(user_id)
    roulette_key = f"{user_id_str}_{roulette_id}"
    
    if roulette_key not in user_action_history:
        user_action_history[roulette_key] = []
    
    history = user_action_history[roulette_key]
    current_time = datetime.now()
    
    # حذف السجلات القديمة (أكثر من 5 دقائق)
    history[:] = [action for action in history if (current_time - datetime.fromisoformat(action['time'])).seconds < 300]
    
    # التحقق من وجود نمط تلاعب (انضمام -> انسحاب -> انضمام -> انسحاب)
    if len(history) >= 4:
        recent = history[-4:]
        if (recent[0]['type'] == 'join' and 
            recent[1]['type'] == 'withdraw' and 
            recent[2]['type'] == 'join' and 
            recent[3]['type'] == 'withdraw'):
            return True, current_time + timedelta(seconds=100)
    
    return False, None

def add_action_to_history(user_id, roulette_id, action_type):
    """إضافة إجراء إلى سجل المستخدم"""
    user_id_str = str(user_id)
    roulette_key = f"{user_id_str}_{roulette_id}"
    
    if roulette_key not in user_action_history:
        user_action_history[roulette_key] = []
    
    user_action_history[roulette_key].append({
        'type': action_type,
        'time': datetime.now().isoformat()
    })
    
    save_data()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    
    # إضافة المستخدم للقائمة
    if user_id not in all_users:
        all_users.add(user_id)
        save_data()
        
        # إشعار دخول للأدمن
        if join_notifications and user_id != ADMIN_ID:
            try:
                username_text = f'@{user.username}' if user.username else 'بدون يوزر'
                notification_text = '<blockquote><b>دخل شخص جديد الى البوت</b></blockquote>\n\n'
                notification_text += f'<blockquote><b>اسمه→ {user.first_name}</b></blockquote>\n'
                notification_text += f'<blockquote><b>يوزره→ {username_text}</b></blockquote>\n'
                notification_text += f'<blockquote><b>ايديه→ {user_id}</b></blockquote>'
                
                await context.bot.send_message(
                    chat_id=ADMIN_ID,
                    text=notification_text,
                    parse_mode='HTML'
                )
            except Exception as e:
                logger.error(f'Error sending join notification: {e}')
    
    # التحقق من الحظر
    if user_id in blocked_users:
        keyboard = [[InlineKeyboardButton("المطور", url=f'tg://user?id={ADMIN_ID}')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            '<blockquote><b>تم حظرك من استخدام البوت</b></blockquote>',
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        return
    
    # التحقق من حالة البوت
    if not bot_active and user_id != ADMIN_ID:
        await update.message.reply_text(
            '<b>البوت متوقف حالياً</b>',
            parse_mode='HTML'
        )
        return
    
    # التحقق من القنوات الإجبارية
    is_subscribed, not_subscribed_channels = await check_forced_channels(user_id, context)
    if not is_subscribed and user_id != ADMIN_ID:
        keyboard = []
        for channel_info in not_subscribed_channels:
            channel_title = channel_info.get('title', 'قناة')
            channel_username = channel_info.get('username', '')
            if channel_username:
                keyboard.append([InlineKeyboardButton(f"اشترك في {channel_title}", url=f'https://t.me/{channel_username}')])
        
        keyboard.append([InlineKeyboardButton("تحقق من الاشتراك", callback_data='check_subscription')])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            '<blockquote><b>يجب الاشتراك في القنوات التالية لاستخدام البوت</b></blockquote>',
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        return
    
    user_link = f'<a href="tg://user?id={user.id}">{user.first_name}</a>'
    
    if context.args and len(context.args) > 0:
        arg = context.args[0]
        
        if arg == 'win':
            if user.id in reminder_users:
                await update.message.reply_text(
                    '<blockquote><b>تم تفعيل ↞ ذَكرني إذا فزت </b></blockquote>\n'
                    '<blockquote><b>سوف يتم ارسال رساله اليك اي سحب تشارك فيه</b></blockquote>',
                    parse_mode='HTML'
                )
            else:
                reminder_users.add(user.id)
                save_data()
                await update.message.reply_text(
                    '<blockquote><b>تم تفعيل ↞ ذَكرني إذا فزت </b></blockquote>\n'
                    '<blockquote><b>سوف يتم ارسال رساله اليك اي سحب تشارك فيه</b></blockquote>',
                    parse_mode='HTML'
                )
            return
        
        elif arg.startswith('join_'):
            roulette_id = arg.replace('join_', '')
            await handle_join_request(update, context, user, roulette_id)
            return
        
        elif arg.startswith('withdraw_'):
            roulette_id = arg.replace('withdraw_', '')
            await handle_withdraw_request(update, context, user, roulette_id)
            return
    
    # حساب الإحصائيات
    stats = get_user_stats(user_id)
    
    keyboard = [
        [InlineKeyboardButton("إنشاء سَحب", callback_data='create_roulette')],
        [
            InlineKeyboardButton("إدارة قنواتي", callback_data='manage_channels'),
            InlineKeyboardButton("قنواتي", callback_data='my_channels')
        ],
        [InlineKeyboardButton("↞ ذَكرني إذا فزت ", url=f'https://t.me/{BOT_USERNAME}?start=win')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_text = f'<b>↞ أهلا {user_link} في سحوبات إيفا</b>\n'
    welcome_text += f'• سحوباتك المنشأة: <code>{stats["created_giveaways"]}</code>\n'
    welcome_text += f'• سحوباتك المشارك بها: <code>{stats["participated_giveaways"]}</code>\n'
    welcome_text += f'• مرات فوزك: <code>{stats["wins"]}</code>\n'
    welcome_text += '<blockquote><b>↞ أسَتخدم الأزرار أدناَه للتحكم.  </b></blockquote>'
    
    await update.message.reply_text(
        welcome_text,
        reply_markup=reply_markup,
        parse_mode='HTML'
    )
    
    # إرسال لوحة الأدمن
    if user_id == ADMIN_ID:
        admin_keyboard = [
            [InlineKeyboardButton("تعيين قناة السحوبات", callback_data='admin_set_broadcast_channel')],
            [
                InlineKeyboardButton("إذاعة", callback_data='admin_broadcast'),
                InlineKeyboardButton("الإحصائيات", callback_data='admin_stats')
            ],
            [
                InlineKeyboardButton("حظر عضو", callback_data='admin_ban_user'),
                InlineKeyboardButton("إلغاء حظر عضو", callback_data='admin_unban_user')
            ],
            [
                InlineKeyboardButton("إشعار دخول", callback_data='admin_toggle_notifications'),
                InlineKeyboardButton("اشتراك اجباري", callback_data='admin_forced_channels')
            ],
            [
                InlineKeyboardButton("تحكم البوت", callback_data='admin_bot_control'),
                InlineKeyboardButton("مسح المحظورين", callback_data='admin_clear_banned')
            ]
        ]
        admin_reply_markup = InlineKeyboardMarkup(admin_keyboard)
        
        await update.message.reply_text(
            '<blockquote><b>لوحة تحكم الأدمن</b></blockquote>',
            reply_markup=admin_reply_markup,
            parse_mode='HTML'
        )

async def handle_join_request(update, context, user, roulette_id):
    """معالجة طلب الانضمام"""
    user_id = user.id
    
    if roulette_id not in roulette_data:
        await update.message.reply_text(
            '<blockquote><b>الروليت غير موجود</b></blockquote>',
            parse_mode='HTML'
        )
        return
    
    roulette = roulette_data[roulette_id]
    
    # التحقق من التلاعب
    is_abuse, cooldown_until = check_withdrawal_abuse(user_id, roulette_id)
    if is_abuse:
        remaining = int((cooldown_until - datetime.now()).total_seconds())
        await update.message.reply_text(
            f'<b>لايمَكنك المُشاركة ألان</b>\n'
            f'<b>إنتظر {remaining} ثانيه</b>',
            parse_mode='HTML'
        )
        return
    
    if not roulette.get('active', True):
        await update.message.reply_text(
            '<b><u>تم ايقاف المشاركة من قبل المشرف</u></b>',
            parse_mode='HTML'
        )
        return
    
    # التحقق من القناة الإجبارية (قناة السحب نفسها)
    channel_id = roulette.get('channel_id')
    try:
        member = await context.bot.get_chat_member(channel_id, user.id)
        if member.status not in ['member', 'administrator', 'creator']:
            await update.message.reply_text(
                '<b><u>لايمَكنك المشُاركة لأنك مامنضم في قناة المسابقة.</u></b>',
                parse_mode='HTML'
            )
            return
    except Exception as e:
        logger.error(f'Error checking channel membership: {e}')
        await update.message.reply_text(
            '<b><u>لايمَكنك المشُاركة لأنك مامنضم في قناة المسابقة.</u></b>',
            parse_mode='HTML'
        )
        return
    
    # التحقق من شرط المستخدمين المميزين
    if roulette.get('premium_required'):
        if not user.is_premium:
            await update.message.reply_text(
                '<b><u>ليس لديك أشتراك مميز</u></b>',
                parse_mode='HTML'
            )
            return
    
    # التحقق من شرط اليوزر الثلاثي
    if roulette.get('triple_username_required'):
        if not user.username or not is_triple_username(user.username):
            await update.message.reply_text(
                '<b><u>عذراً، يجب أن يكون يوزرك ثلاثي مثل #_#_#</u></b>',
                parse_mode='HTML'
            )
            return
    
    # التحقق من القناة الإجبارية الإضافية
    if roulette.get('mandatory_channel'):
        try:
            mandatory_username = roulette['mandatory_channel']
            member = await context.bot.get_chat_member(f'@{mandatory_username}', user.id)
            if member.status not in ['member', 'administrator', 'creator']:
                await update.message.reply_text(
                    '<b><u>لايمَكنك المشُاركة لأنك مامنضم في قناة المسابقة.</u></b>',
                    parse_mode='HTML'
                )
                return
        except Exception as e:
            logger.error(f'Error checking mandatory channel: {e}')
            await update.message.reply_text(
                '<b><u>لايمَكنك المشُاركة لأنك مامنضم في قناة المسابقة.</u></b>',
                parse_mode='HTML'
            )
            return
    
    # التحقق من شرط التعزيز
    if roulette.get('boost_channel'):
        boost_username = roulette['boost_channel']
        boost_link = f'https://t.me/boost/{boost_username}'
        
        keyboard = [
            [InlineKeyboardButton("تعزيز القناة", url=boost_link)],
            [InlineKeyboardButton("تحقق من التعزيز", callback_data=f'check_boost_{roulette_id}')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            '<blockquote><b>يجب تعزيز القناة للمشاركة</b></blockquote>\n'
            '<blockquote><b>بعد التعزيز اضغط على زر "تحقق من التعزيز"</b></blockquote>',
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        return
    
    # التحقق من التسجيل المسبق
    already_joined = False
    if roulette_id in participant_data:
        for participant in participant_data[roulette_id]:
            if participant['user_id'] == user.id:
                already_joined = True
                break
    
    if already_joined:
        await update.message.reply_text(
            '<blockquote><b>أنت مسجل بالفعل في السحب</b></blockquote>',
            parse_mode='HTML'
        )
        return
    
    # اختبار الإيموجي
    emojis = ['🎯', '🎲', '🎰', '🎪', '🎭', '🎨', '🎬', '🎤', '🎧', '🎼']
    correct_emoji = random.choice(emojis)
    shuffled_emojis = random.sample(emojis, 3)
    
    if correct_emoji not in shuffled_emojis:
        shuffled_emojis[0] = correct_emoji
        random.shuffle(shuffled_emojis)
    
    context.user_data['correct_emoji'] = correct_emoji
    context.user_data['roulette_id'] = roulette_id
    context.user_data['action_type'] = 'join'
    
    keyboard = []
    for emoji in shuffled_emojis:
        keyboard.append([InlineKeyboardButton(emoji, callback_data=f'verify_{emoji}_{roulette_id}_join')])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    verification_text = '<blockquote><b>لتأكد إنك مو روبوت</b></blockquote>\n'
    verification_text += f'<blockquote><b>اضغط على الزر اللي يشبه هذا الإيموجي {correct_emoji}</b></blockquote>'
    
    await update.message.reply_text(
        verification_text,
        reply_markup=reply_markup,
        parse_mode='HTML'
    )

async def handle_withdraw_request(update, context, user, roulette_id):
    """معالجة طلب الانسحاب"""
    user_id = user.id
    
    if roulette_id not in roulette_data:
        await update.message.reply_text(
            '<blockquote><b>الروليت غير موجود</b></blockquote>',
            parse_mode='HTML'
        )
        return
    
    # التحقق من المشاركة
    is_participant = False
    if roulette_id in participant_data:
        for participant in participant_data[roulette_id]:
            if participant['user_id'] == user.id:
                is_participant = True
                break
    
    if not is_participant:
        await update.message.reply_text(
            '<blockquote><b>أنت لسَت مُشارك في إلسَحب.</b></blockquote>',
            parse_mode='HTML'
        )
        return
    
    # اختبار الإيموجي للانسحاب
    emojis = ['🎯', '🎲', '🎰', '🎪', '🎭', '🎨', '🎬', '🎤', '🎧', '🎼']
    correct_emoji = random.choice(emojis)
    shuffled_emojis = random.sample(emojis, 3)
    
    if correct_emoji not in shuffled_emojis:
        shuffled_emojis[0] = correct_emoji
        random.shuffle(shuffled_emojis)
    
    context.user_data['correct_emoji'] = correct_emoji
    context.user_data['roulette_id'] = roulette_id
    context.user_data['action_type'] = 'withdraw'
    
    keyboard = []
    for emoji in shuffled_emojis:
        keyboard.append([InlineKeyboardButton(emoji, callback_data=f'verify_{emoji}_{roulette_id}_withdraw')])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    verification_text = '<blockquote><b>لتأكد إنك مو روبوت</b></blockquote>\n'
    verification_text += f'<blockquote><b>اضغط على الزر اللي يشبه هذا الإيموجي {correct_emoji}</b></blockquote>'
    
    await update.message.reply_text(
        verification_text,
        reply_markup=reply_markup,
        parse_mode='HTML'
    )

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    
    user_id = query.from_user.id
    data = get_user_data(user_id)
    
    # التحقق من الحظر
    if user_id in blocked_users and not query.data.startswith('admin_'):
        try:
            await query.answer('تم حظرك من استخدام البوت', show_alert=True)
        except:
            pass
        keyboard = [[InlineKeyboardButton("المطور", url=f'tg://user?id={ADMIN_ID}')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        try:
            await query.edit_message_text(
                '<blockquote><b>تم حظرك من استخدام البوت</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
        return
    
    # التحقق من القنوات الإجبارية
    if query.data == 'check_subscription':
        is_subscribed, not_subscribed_channels = await check_forced_channels(user_id, context)
        if not is_subscribed:
            try:
                await query.answer('لم تشترك في جميع القنوات بعد', show_alert=True)
            except:
                pass
            return
        else:
            try:
                await query.answer('تم التحقق بنجاح!', show_alert=True)
            except:
                pass
            # إعادة إرسال القائمة الرئيسية
            stats = get_user_stats(user_id)
            
            keyboard = [
                [InlineKeyboardButton("إنشاء سَحب", callback_data='create_roulette')],
                [
                    InlineKeyboardButton("إدارة قنواتي", callback_data='manage_channels'),
KeyboardButton("قنواتي", callback_data='my_channels')
                ],
                [InlineKeyboardButton("↞ ذَكرني إذا فزت ", url=f'https://t.me/{BOT_USERNAME}?start=win')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            user_link = f'<a href="tg://user?id={user_id}">{query.from_user.first_name}</a>'
            welcome_text = f'<b>↞ أهلا {user_link} في سحوبات إيفا</b>\n'
            welcome_text += f'• سحوباتك المنشأة: <code>{stats["created_giveaways"]}</code>\n'
            welcome_text += f'• سحوباتك المشارك بها: <code>{stats["participated_giveaways"]}</code>\n'
            welcome_text += f'• مرات فوزك: <code>{stats["wins"]}</code>\n'
            welcome_text += '<blockquote><b>↞ أسَتخدم الأزرار أدناَه للتحكم.  </b></blockquote>'
            
            try:
                await query.edit_message_text(
                    welcome_text,
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
            except:
                pass
            return
    
    # معالجة الأزرار الرئيسية
    if query.data == 'create_roulette':
        try:
            await query.answer()
        except:
            pass
        if not data['channels']:
            keyboard = [[InlineKeyboardButton("إضافة قناة", callback_data='add_channel')],
                       [InlineKeyboardButton("رجوع", callback_data='back_to_main')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            try:
                await query.edit_message_text(
                    '<blockquote><b>لا توجد قنوات مضافة، الرجاء إضافة قناة أولاً</b></blockquote>',
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
            except:
                pass
            return
        
        keyboard = []
        for channel in data['channels']:
            channel_title = channel.get('title', 'قناة')
            channel_id = channel.get('id')
            keyboard.append([InlineKeyboardButton(channel_title, callback_data=f'select_channel_{channel_id}')])
        
        keyboard.append([InlineKeyboardButton("رجوع", callback_data='back_to_main')])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                '<blockquote><b>اختر القناة التي تريد إنشاء السحب فيها</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'manage_channels':
        try:
            await query.answer()
        except:
            pass
        keyboard = [
            [InlineKeyboardButton("إضافة قناة عامة", callback_data='add_channel')],
            [InlineKeyboardButton("إضافة قناة خاصة", callback_data='add_private_channel')],
            [InlineKeyboardButton("رجوع", callback_data='back_to_main')]
        ]
        
        if data['channels']:
            keyboard.insert(1, [InlineKeyboardButton("حذف قناة", callback_data='remove_channel_menu')])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                '<blockquote><b>إدارة القنوات</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'my_channels':
        try:
            await query.answer()
        except:
            pass
        if not data['channels']:
            keyboard = [[InlineKeyboardButton("رجوع", callback_data='back_to_main')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            try:
                await query.edit_message_text(
                    '<blockquote><b>لا توجد قنوات مضافة</b></blockquote>',
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
            except:
                pass
            return
        
        channels_text = '<blockquote><b>قنواتي:</b></blockquote>\n\n'
        for idx, channel in enumerate(data['channels'], 1):
            channel_title = channel.get('title', 'قناة')
            channel_username = channel.get('username', 'غير معروف')
            channels_text += f'<blockquote><b>{idx}. {channel_title} (@{channel_username})</b></blockquote>\n'
        
        keyboard = [[InlineKeyboardButton("رجوع", callback_data='back_to_main')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                channels_text,
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'add_channel':
        try:
            await query.answer()
        except:
            pass
        data['state'] = 'waiting_channel_username'
        try:
            await query.edit_message_text(
                '<b>أرسل يوزر القناة </b>\n'
                '<blockquote>تأكد أن البوت مشرف في القناة</blockquote>',
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'add_private_channel':
        try:
            await query.answer()
        except:
            pass
        data['state'] = 'waiting_private_channel'
        try:
            await query.edit_message_text(
                '<b>أرسل رابط القناة الخاصة</b>\n'
                '<blockquote>تأكد أن البوت مشرف في القناة</blockquote>',
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'remove_channel_menu':
        try:
            await query.answer()
        except:
            pass
        keyboard = []
        for channel in data['channels']:
            channel_title = channel.get('title', 'قناة')
            channel_id = channel.get('id')
            keyboard.append([InlineKeyboardButton(f"حذف {channel_title}", callback_data=f'remove_channel_{channel_id}')])
        
        keyboard.append([InlineKeyboardButton("رجوع", callback_data='manage_channels')])
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                '<blockquote><b>اختر القناة التي تريد حذفها</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data.startswith('remove_channel_'):
        channel_id = query.data.replace('remove_channel_', '')
        
        data['channels'] = [ch for ch in data['channels'] if str(ch.get('id')) != str(channel_id)]
        save_data()
        
        try:
            await query.answer('تم حذف القناة بنجاح', show_alert=True)
        except:
            pass
        
        keyboard = [[InlineKeyboardButton("رجوع", callback_data='manage_channels')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                '<blockquote><b>تم حذف القناة بنجاح</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data.startswith('select_channel_'):
        try:
            await query.answer()
        except:
            pass
        channel_id = query.data.replace('select_channel_', '')
        
        data['temp_data']['selected_channel'] = channel_id
        data['state'] = 'waiting_template'
        
        template_instructions = '<b>أرسل الرسالة التى تريد ان تظهر فى السحب</b>\n'
        template_instructions += '<b>وتكدر تستعمل اشگال الجاهزه لتغير شكل الخط</b>\n'
        template_instructions += '<b>امسح كلمة هنا وحط الكَتابة الي تريدها يحلو.</b>\n\n'
        
        template_instructions += '<b>1 - للتشويش:</b>\n'
        template_instructions += '<tg-spoiler>مثال</tg-spoiler>\n'
        template_instructions += '<code>&lt;tg-spoiler&gt;هنا&lt;/tg-spoiler&gt;</code>\n\n'
        
        template_instructions += '<b>2 - للتعريض:</b>\n'
        template_instructions += '<b>مثال</b>\n'
        template_instructions += '<code>&lt;b&gt;هنا&lt;/b&gt;</code>\n\n'
        
        template_instructions += '<b>3 - للنص المائل:</b>\n'
        template_instructions += '<i>مثال</i>\n'
        template_instructions += '<code>&lt;i&gt;هنا&lt;/i&gt;</code>\n\n'
        
        template_instructions += '<b>4 - للمقتبس:</b>\n'
        template_instructions += '<blockquote>مثال</blockquote>\n'
        template_instructions += '<code>&lt;blockquote&gt;هنا&lt;/blockquote&gt;</code>\n\n'
        
        template_instructions += '<b>⚠️ رجاءً عدم إرسال أي روابط نهائياً</b>'
        
        try:
            await query.edit_message_text(
                template_instructions,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'settings_menu':
        try:
            await query.answer()
        except:
            pass
        keyboard = [
            [InlineKeyboardButton("أضف قناة اجباري", callback_data='add_mandatory_channel')],
            [InlineKeyboardButton("أضف شرط تعزيز القناة", callback_data='add_boost_requirement')],
            [InlineKeyboardButton("أضف شرط يوزر ثلاثي", callback_data='add_triple_username')],
            [InlineKeyboardButton("أضف المستخدمين المميزين", callback_data='add_premium_requirement')],
            [InlineKeyboardButton("اضافة السحب التلقائي", callback_data='add_auto_draw')],
            [InlineKeyboardButton("حفظ ألاعدادات", callback_data='save_settings')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                '<blockquote><b>تم حفظ الكليشة ألان اختار شيء من الاعدادات السحب</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'add_mandatory_channel':
        try:
            await query.answer()
        except:
            pass
        data['state'] = 'waiting_mandatory_channel'
        try:
            await query.edit_message_text(
                '<b>أرسل رابط أو يوزر القناة الإجبارية</b>\n'
                '<blockquote>تأكد أن البوت مشرف في القناة</blockquote>',
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'add_boost_requirement':
        try:
            await query.answer()
        except:
            pass
        data['state'] = 'waiting_boost_channel'
        try:
            await query.edit_message_text(
                '<b>أرسل رابط أو يوزر القناة التي تريد التعزيز فيها</b>\n'
                '<blockquote>تأكد أن البوت مشرف في القناة</blockquote>',
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'add_triple_username':
        data['temp_data']['triple_username_required'] = True
        save_data()
        try:
            await query.answer('تم إضافة شرط اليوزر الثلاثي', show_alert=True)
        except:
            pass
        
        keyboard = [[InlineKeyboardButton("رجوع", callback_data='settings_menu')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                '<blockquote><b>تم إضافة شرط اليوزر الثلاثي</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'add_premium_requirement':
        try:
            await query.answer()
        except:
            pass
        premium_text = 'هذا الميزة لازم المستخدم لديه اشتراك مميز (<u>Premium</u>).\n\n'
        premium_text += '<blockquote><b>أذا كنت تُريد تَفعيل الميزة اضغط على زر ( تفعيل )</b></blockquote>'
        
        keyboard = [
            [InlineKeyboardButton("تفعيل", callback_data='activate_premium_requirement')],
            [InlineKeyboardButton("تخطي", callback_data='settings_menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                premium_text,
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'activate_premium_requirement':
        data['temp_data']['premium_required'] = True
        save_data()
        try:
            await query.answer('تم تفعيل شرط المستخدمين المميزين', show_alert=True)
        except:
            pass
        
        keyboard = [[InlineKeyboardButton("رجوع", callback_data='settings_menu')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        try:
            await query.edit_message_text(
                '<blockquote><b>تم تفعيل شرط المستخدمين المميزين</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'add_auto_draw':
        try:
            await query.answer()
        except:
            pass
        data['state'] = 'waiting_auto_draw_count'
        try:
            await query.edit_message_text(
                '<blockquote><b>أرسل عدد المشاركين للسحب التلقائي</b></blockquote>',
                parse_mode='HTML'
            )
        except:
            pass
    
    elif query.data == 'save_settings':
        try:
            await query.answer()
        except:
            pass
        data['state'] = 'waiting_winners_count'
        try:
            await query.edit_message_text(
                '<blockquote><b>أرسل عدد الفائزين في السحب</b></blockquote>',
                parse_mode='HTML'
            )
        except:
            pass
    
    # التحقق من التعزيز
    elif query.data.startswith('check_boost_'):
        roulette_id = query.data.replace('check_boost_', '')
        roulette = roulette_data.get(roulette_id)
        
        if not roulette:
            try:
                await query.answer('الروليت غير موجود', show_alert=True)
            except:
                pass
            return
        
        # التحقق من التسجيل المسبق
        already_joined = False
        if roulette_id in participant_data:
            for participant in participant_data[roulette_id]:
                if participant['user_id'] == user_id:
                    already_joined = True
                    break
        
        if not already_joined:
            # التحقق من قناة السحب أولاً
            channel_id = roulette.get('channel_id')
            try:
                member = await context.bot.get_chat_member(channel_id, user_id)
                if member.status not in ['member', 'administrator', 'creator']:
                    try:
                        await query.answer('لايمَكنك المشُاركة لأنك مامنضم في قناة المسابقة.', show_alert=True)
                    except:
                        pass
                    return
            except Exception as e:
                logger.error(f'Error checking channel membership: {e}')
                try:
                    await query.answer('لايمَكنك المشُاركة لأنك مامنضم في قناة المسابقة.', show_alert=True)
                except:
                    pass
                return
            
            # التحقق من شرط المستخدمين المميزين
            if roulette.get('premium_required'):
                if not query.from_user.is_premium:
                    try:
                        await query.answer('ليس لديك أشتراك مميز', show_alert=True)
                    except:
                        pass
                    return
            
            # التحقق من شرط اليوزر الثلاثي
            if roulette.get('triple_username_required'):
                if not query.from_user.username or not is_triple_username(query.from_user.username):
                    try:
                        await query.answer('عذراً، يجب أن يكون يوزرك ثلاثي مثل #_#_#', show_alert=True)
                    except:
                        pass
                    return
            
            # التحقق من أن المستخدم مشترك في القناة على الأقل
            boost_username = roulette.get('boost_channel')
            if boost_username:
                try:
                    chat = await context.bot.get_chat(f'@{boost_username}')
                    member = await context.bot.get_chat_member(chat.id, user_id)
                    
                    if member.status not in ['member', 'administrator', 'creator']:
                        try:
                            await query.answer('يجب الاشتراك في القناة أولاً', show_alert=True)
                        except:
                            pass
                        return
                except:
                    pass
            
            # إضافة المشارك - التحقق من الإيموجي
            emojis = ['🎯', '🎲', '🎰', '🎪', '🎭', '🎨', '🎬', '🎤', '🎧', '🎼']
            correct_emoji = random.choice(emojis)
            shuffled_emojis = random.sample(emojis, 3)
            
            if correct_emoji not in shuffled_emojis:
                shuffled_emojis[0] = correct_emoji
                random.shuffle(shuffled_emojis)
            
            context.user_data['correct_emoji'] = correct_emoji
            context.user_data['roulette_id'] = roulette_id
            context.user_data['from_boost_check'] = True
            context.user_data['action_type'] = 'join'
            
            keyboard = []
            for emoji in shuffled_emojis:
                keyboard.append([InlineKeyboardButton(emoji, callback_data=f'verify_{emoji}_{roulette_id}_join')])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            verification_text = '<blockquote><b>تم التحقق من التعزيز!</b></blockquote>\n'
            verification_text += '<blockquote><b>لتأكد إنك مو روبوت</b></blockquote>\n'
            verification_text += f'<blockquote><b>اضغط على الزر اللي يشبه هذا الإيموجي {correct_emoji}</b></blockquote>'
            
            try:
                await query.edit_message_text(
                    verification_text,
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
            except:
                try:
                    await query.message.reply_text(
                        verification_text,
                        reply_markup=reply_markup,
                        parse_mode='HTML'
                    )
                except:
                    pass
        else:
            try:
                await query.answer('أنت مسجل بالفعل في السحب', show_alert=True)
            except:
                pass
        return
    
    # معالجة التحقق من الإيموجي
    elif query.data.startswith('verify_'):
        parts = query.data.split('_')
        if len(parts) >= 4:
            selected_emoji = parts[1]
            action_type = parts[-1]  # join or withdraw
            roulette_id = '_'.join(parts[2:-1])
            
            correct_emoji = context.user_data.get('correct_emoji')
            stored_roulette_id = context.user_data.get('roulette_id')
            stored_action = context.user_data.get('action_type')
            
            if selected_emoji == correct_emoji and roulette_id == stored_roulette_id and action_type == stored_action:
                if action_type == 'join':
                    # إضافة المشارك
                    if roulette_id not in participant_data:
                        participant_data[roulette_id] = []
                    
                    participant_info = {
                        'user_id': user_id,
                        'first_name': query.from_user.first_name,
                        'username': query.from_user.username
                    }
                    
                    participant_data[roulette_id].append(participant_info)
                    
                    # تسجيل الإجراء
                    add_action_to_history(user_id, roulette_id, 'join')
                    
                    # تحديث إحصائيات المستخدم
                    update_user_stats(user_id, 'participated_giveaways', 1)
                    
                    save_data()
                    
                    try:
                        await query.answer('تم تسجيلك في السحب', show_alert=True)
                    except:
                        pass
                    try:
                        await query.edit_message_text(
                            '<blockquote><b>تم تسجيلك في السحب بنجاح!</b></blockquote>',
                            parse_mode='HTML'
                        )
                    except:
                        pass
                    
                    # تحديث عدد المشاركين
                    await update_participants_count(context, roulette_id)
                    
                    # التحقق من السحب التلقائي
                    roulette = roulette_data.get(roulette_id)
                    if roulette and roulette.get('auto_draw_enabled'):
                        auto_draw_count = roulette.get('auto_draw_count', 0)
                        current_count = len(participant_data.get(roulette_id, []))
                        
                        if current_count >= auto_draw_count:
                            await perform_draw(context, roulette_id, roulette, auto_draw=True)
                    
                elif action_type == 'withdraw':
                    # حذف المشارك
                    if roulette_id in participant_data:
                        participant_data[roulette_id] = [p for p in participant_data[roulette_id] if p['user_id'] != user_id]
                        
                        # تسجيل الإجراء
                        add_action_to_history(user_id, roulette_id, 'withdraw')
                        
                        # تحديث إحصائيات المستخدم
                        update_user_stats(user_id, 'participated_giveaways', -1)
                        
                        save_data()
                        
                        try:
                            await query.answer('تَم إنسحَابك من المُسابقة.', show_alert=True)
                        except:
                            pass
                        try:
                            await query.edit_message_text(
                                '<blockquote><b>تَم إنسحَابك من المُسابقة.</b></blockquote>',
                                parse_mode='HTML'
                            )
                        except:
                            pass
                        
                        # تحديث عدد المشاركين
                        await update_participants_count(context, roulette_id)
                
                # حذف بيانات التحقق
                context.user_data.pop('correct_emoji', None)
                context.user_data.pop('roulette_id', None)
                context.user_data.pop('from_boost_check', None)
                context.user_data.pop('action_type', None)
            else:
                try:
                    await query.answer('إيموجي خاطئ! حاول مرة أخرى', show_alert=True)
                except:
                    pass
    
    # إيقاف وتفعيل المشاركة
    elif query.data.startswith('stop_participation_'):
        roulette_id = query.data.replace('stop_participation_', '')
        
        roulette = roulette_data.get(roulette_id)
        if not roulette:
            try:
                await query.answer('الروليت غير موجود', show_alert=True)
            except:
                pass
            return
        
        if roulette.get('owner_id') != user_id:
            try:
                await query.answer('غير مصرح لك', show_alert=True)
            except:
                pass
            return
        
        roulette['active'] = False
        roulette_status[roulette_id] = False
        save_data()
        
        try:
            await query.answer('تم إيقاف المشاركة', show_alert=True)
        except:
            pass
        await update_participants_count(context, roulette_id)
    
    elif query.data.startswith('activate_participation_'):
        roulette_id = query.data.replace('activate_participation_', '')
        
        roulette = roulette_data.get(roulette_id)
        if not roulette:
            try:
                await query.answer('الروليت غير موجود', show_alert=True)
            except:
                pass
            return
        
        if roulette.get('owner_id') != user_id:
            try:
                await query.answer('غير مصرح لك', show_alert=True)
            except:
                pass
            return
        
        roulette['active'] = True
        roulette_status[roulette_id] = True
        save_data()
        
        try:
            await query.answer('تم تفعيل المشاركة', show_alert=True)
        except:
            pass
        await update_participants_count(context, roulette_id)
    
    # تصفية المغادرين
    elif query.data.startswith('filter_left_'):
        roulette_id = query.data.replace('filter_left_', '')
        
        roulette = roulette_data.get(roulette_id)
        if not roulette:
            try:
                await query.answer('الروليت غير موجود', show_alert=True)
            except:
                pass
            return
        
        if roulette.get('owner_id') != user_id:
            try:
                await query.answer('غير مصرح لك', show_alert=True)
            except:
                pass
            return
        
        participants = participant_data.get(roulette_id, [])
        channel_id = roulette.get('channel_id')
        
        if not participants:
            try:
                await query.answer('لا يوجد مشاركين', show_alert=True)
            except:
                pass
            return
        
        removed_participants = []
        new_participants = []
        
        for participant in participants:
            try:
                member = await context.bot.get_chat_member(channel_id, participant['user_id'])
                if member.status in ['member', 'administrator', 'creator']:
                    new_participants.append(participant)
                else:
                    removed_participants.append(participant)
            except:
                removed_participants.append(participant)
        
        participant_data[roulette_id] = new_participants
        save_data()
        
        if removed_participants:
            for removed in removed_participants:
                try:
                    notification_text = 'هنالك شخص قام بالانضمام في السحب وغادر\n\n'
                    notification_text += f'اسمه ↞ {removed["first_name"]}\n'
                    notification_text += f'يوزره ↞ @{removed["username"] if removed.get("username") else "بدون يوزر"}\n'
                    notification_text += f'ايديه ↞ {removed["user_id"]}'
                    
                    await context.bot.send_message(
                        chat_id=user_id,
                        text=notification_text,
                        parse_mode='HTML'
                    )
                except Exception as e:
                    logger.error(f'Error sending removal notification: {e}')
            
            try:
                await query.answer(f'تم استبعاد {len(removed_participants)} مشارك', show_alert=True)
            except:
                pass
        else:
            try:
                await query.answer('لا يوجد مغادرين', show_alert=True)
            except:
                pass
        
        await update_participants_count(context, roulette_id)
    
    # بدء السحب
    elif query.data.startswith('draw_roulette_'):
        roulette_id = query.data.replace('draw_roulette_', '')
        
        roulette = roulette_data.get(roulette_id)
        if not roulette:
            try:
                await query.answer('الروليت غير موجود', show_alert=True)
            except:
                pass
            return
        
        if roulette.get('owner_id') != user_id:
            try:
                await query.answer('غير مصرح لك', show_alert=True)
            except:
                pass
            return
        
        # التحقق من إيقاف المشاركة
        if roulette.get('active', True):
            try:
                await query.answer('يَجب أيقاف مُشاركة السحب للبَدء', show_alert=True)
            except:
                pass
            return
        
        participants = participant_data.get(roulette_id, [])
        
        if not participants or len(participants) == 0:
            try:
                await query.answer('لا يوجد مشاركين في السحب', show_alert=True)
            except:
                pass
            return
        
        # التحقق من وجود لاعبين على الأقل
        if len(participants) < 2:
            try:
                await query.answer('يجب أن يكون هناك على الأقل لاعبين للبدء بالسحب', show_alert=True)
            except:
                pass
            return
        
        await perform_draw(context, roulette_id, roulette)
        try:
            await query.answer('تم إجراء السحب بنجاح', show_alert=True)
        except:
            pass
    
    elif query.data.startswith('draw_another_'):
        roulette_id = query.data.replace('draw_another_', '')
        
        roulette = roulette_data.get(roulette_id)
        if not roulette:
            try:
                await query.answer('الروليت غير موجود', show_alert=True)
            except:
                pass
            return
        
        if roulette.get('owner_id') != user_id:
            try:
                await query.answer('غير مصرح لك', show_alert=True)
            except:
                pass
            return
        
        participants = participant_data.get(roulette_id, [])
        
        if not participants or len(participants) == 0:
            try:
                await query.answer('لا يوجد مشاركين متبقين', show_alert=True)
            except:
                pass
            return
        
        channel_id = roulette.get('channel_id')
        
        await context.bot.send_message(
            chat_id=channel_id,
            text='<b>يتم سحب فائز أخر</b>',
            parse_mode='HTML'
        )
        
        await asyncio.sleep(5)
        
        # سحب فائز جديد
        winner = random.choice(participants)
        
        # حذف الفائز من القائمة
        participant_data[roulette_id] = [p for p in participant_data[roulette_id] if p['user_id'] != winner['user_id']]
        
        # تحديث إحصائيات الفائز
        update_user_stats(winner['user_id'], 'wins', 1)
        
        save_data()
        
        winner_link = f'<a href="tg://user?id={winner["user_id"]}">{winner["first_name"]}</a>'
        
        result_text = '<b>الفائز الجديد</b>\n\n'
        result_text += f'<blockquote><b>1. {winner_link}</b></blockquote>\n'
        result_text += f'\n{get_footer_text()}'
        
        keyboard = [[InlineKeyboardButton("سحب فائز أخر", callback_data=f'draw_another_{roulette_id}')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=channel_id,
            text=result_text,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        
        # إرسال رسالة إضافية إن وجدت
        if roulette.get('win_message'):
            await asyncio.sleep(2)
            await context.bot.send_message(
                chat_id=channel_id,
                text=f'<b>{roulette["win_message"]}</b>',
                parse_mode='HTML'
            )
        
        # إشعار الفائز
        if winner['user_id'] in reminder_users:
            try:
                channel_username = 'القناة'
                for ch in get_user_data(roulette['owner_id'])['channels']:
                    if str(ch.get('id')) == str(channel_id):
                        channel_username = f"@{ch.get('username', 'القناة')}"
                        break
                
                win_text = '<blockquote><b>مبروك لقد فزت بجائزة السحب</b></blockquote>\n'
                win_text += f'<blockquote><b>في قناة {channel_username}</b></blockquote>'
                
                await context.bot.send_message(
                    chat_id=winner['user_id'],
                    text=win_text,
                    parse_mode='HTML'
                )
            except Exception as e:
                logger.error(f'Error sending win notification: {e}')
        
        try:
            await query.answer('تم سحب فائز جديد', show_alert=True)
        except:
            pass
    
    elif query.data.startswith('republish_'):
        roulette_id = query.data.replace('republish_', '')
        
        roulette = roulette_data.get(roulette_id)
        if not roulette:
            try:
                await query.answer('الروليت غير موجود', show_alert=True)
            except:
                pass
            return
        
        if roulette.get('owner_id') != user_id:
            try:
                await query.answer('غير مصرح لك', show_alert=True)
            except:
                pass
            return
        
        participant_data[roulette_id] = []
        roulette['active'] = True
        roulette_status[roulette_id] = True
        
        new_roulette_id = f"roulette_{user_id}_{random.randint(10000, 99999)}_{int(datetime.now().timestamp())}"
        
        roulette_data[new_roulette_id] = roulette.copy()
        roulette_data[new_roulette_id]['created_at'] = datetime.now()
        participant_data[new_roulette_id] = []
        roulette_status[new_roulette_id] = True
        
        del roulette_data[roulette_id]
        if roulette_id in participant_data:
            del participant_data[roulette_id]
        if roulette_id in roulette_status:
            del roulette_status[roulette_id]
        
        save_data()
        
        channel_id = roulette.get('channel_id')
        channel_username = roulette.get('channel_username', 'channel')
        channel_title = roulette.get('channel_title', 'القناة')
        
        try:
            roulette_text = await build_roulette_message(roulette, new_roulette_id)
            
            participants_count = 0
            join_url = f'https://t.me/{BOT_USERNAME}?start=join_{new_roulette_id}'
            withdraw_url = f'https://t.me/{BOT_USERNAME}?start=withdraw_{new_roulette_id}'
            share_url = f'https://t.me/share/url?url={join_url}'
            
            keyboard = [
                [InlineKeyboardButton(f"أنَضمام [{participants_count}]", url=join_url)],
                [InlineKeyboardButton("إنسَحاب", url=withdraw_url)],
                [
                    InlineKeyboardButton("بَدأ السَحب", callback_data=f'draw_roulette_{new_roulette_id}'),
                    InlineKeyboardButton("أوقف المُشاركة", callback_data=f'stop_participation_{new_roulette_id}')
                ],
                [InlineKeyboardButton("تَصفيه المُغادرين", callback_data=f'filter_left_{new_roulette_id}')],
                [InlineKeyboardButton("ذَكرني إذا فزت", url=f'https://t.me/{BOT_USERNAME}?start=win')],
                [
                    InlineKeyboardButton("مشاركة السحب", url=share_url),
                    InlineKeyboardButton("إعادة النشر", callback_data=f'republish_{new_roulette_id}')
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            sent_message = await context.bot.send_message(
                chat_id=channel_id,
                text=roulette_text,
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            
            roulette_data[new_roulette_id]['message_id'] = sent_message.message_id
            
            # رابط المنشور
            post_url = f'https://t.me/{channel_username}/{sent_message.message_id}'
            roulette_data[new_roulette_id]['post_url'] = post_url
            
            save_data()
            
            # إشعار قناة السحوبات
            if broadcast_channel_id:
                try:
                    broadcast_text = '<blockquote><b>تم انشاء سحب جديد</b></blockquote>\n\n'
                    broadcast_text += f'<blockquote><b>{roulette.get("template", "")}</b></blockquote>\n\n'
                    
                    channel_link_text = f'<a href="https://t.me/{channel_username}">{channel_title}</a>'
                    broadcast_text += f'<blockquote><b>قناة السحب: {channel_link_text}</b></blockquote>'
                    
                    broadcast_keyboard = [[InlineKeyboardButton("رابط السحب", url=post_url)]]
                    broadcast_reply_markup = InlineKeyboardMarkup(broadcast_keyboard)
                    
                    await context.bot.send_message(
                        chat_id=broadcast_channel_id,
                        text=broadcast_text,
                        reply_markup=broadcast_reply_markup,
                        parse_mode='HTML'
                    )
                except Exception as e:
                    logger.error(f'Error broadcasting to channel: {e}')
            
            try:
                await query.answer('تم إعادة نشر الروليت بنجاح', show_alert=True)
            except:
                pass
            
        except Exception as e:
            logger.error(f'Error republishing: {e}')
            try:
                await query.answer('حدث خطأ في إعادة النشر', show_alert=True)
            except:
                pass
    
    elif query.data == 'back_to_main':
        try:
            await query.answer()
        except:
            pass
        
        stats = get_user_stats(user_id)
        
        keyboard = [
            [InlineKeyboardButton("إنشاء سَحب", callback_data='create_roulette')],
            [
                InlineKeyboardButton("إدارة قنواتي", callback_data='manage_channels'),
                InlineKeyboardButton("قنواتي", callback_data='my_channels')
            ],
            [InlineKeyboardButton("↞ ذَكرني إذا فزت ", url=f'https://t.me/{BOT_USERNAME}?start=win')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        user_link = f'<a href="tg://user?id={user_id}">{query.from_user.first_name}</a>'
        welcome_text = f'<b>↞ أهلا {user_link} في سحوبات إيفا</b>\n'
        welcome_text += f'• سحوباتك المنشأة: <code>{stats["created_giveaways"]}</code>\n'
        welcome_text += f'• سحوباتك المشارك بها: <code>{stats["participated_giveaways"]}</code>\n'
        welcome_text += f'• مرات فوزك: <code>{stats["wins"]}</code>\n'
        welcome_text += '<blockquote><b>↞ أسَتخدم الأزرار أدناَه للتحكم.  </b></blockquote>'
        
        try:
            await query.edit_message_text(
                welcome_text,
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except:
            pass
    
    # أوامر الأدمن
    elif query.data.startswith('admin_'):
        if user_id != ADMIN_ID:
            try:
                await query.answer('غير مصرح لك', show_alert=True)
            except:
                pass
            return
        
        if query.data == 'admin_set_broadcast_channel':
            try:
                await query.answer()
            except:
                pass
            data['state'] = 'waiting_broadcast_channel'
            try:
                await query.edit_message_text(
                    '<blockquote><b>أرسل يوزر أو رابط قناة السحوبات</b></blockquote>\n'
                    '<blockquote><b>يجب رفع البوت مشرف في القناة</b></blockquote>',
                    parse_mode='HTML'
                )
            except:
                pass
        
        elif query.data == 'admin_broadcast':
            try:
                await query.answer()
            except:
                pass
            data['state'] = 'waiting_broadcast_message'
            try:
                await query.edit_message_text(
                    '<blockquote><b>أرسل الرسالة التي تريد إذاعتها لجميع المستخدمين</b></blockquote>',
                    parse_mode='HTML'
                )
            except:
                pass
        
        elif query.data == 'admin_stats':
            try:
                await query.answer()
            except:
                pass
            total_users = len(all_users)
            total_blocked = len(blocked_users)
            total_giveaways = len(roulette_data)
            active_giveaways = sum(1 for r in roulette_data.values() if r.get('active', False))
            
            stats_text = '<blockquote><b>احصائيات البوت</b></blockquote>\n\n'
            stats_text += f'<blockquote><b>عدد السحوبات: {total_giveaways}</b></blockquote>\n'
            stats_text += f'<blockquote><b>عدد المستخدمين: {total_users}</b></blockquote>\n'
            stats_text += f'<blockquote><b>عدد الذين حظروا البوت: {total_blocked}</b></blockquote>\n'
            stats_text += f'<blockquote><b>عدد السحوبات النشطة: {active_giveaways}</b></blockquote>'
            
            keyboard = [[InlineKeyboardButton("رجوع", callback_data='admin_back')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            try:
                await query.edit_message_text(
                    stats_text,
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
            except:
                pass
        
        elif query.data == 'admin_ban_user':
            try:
                await query.answer()
            except:
                pass
            data['state'] = 'waiting_ban_user_id'
            try:
                await query.edit_message_text(
                    '<blockquote><b>أرسل آيدي العضو الذي تريد حظره</b></blockquote>',
                    parse_mode='HTML'
                )
            except:
                pass
        
        elif query.data == 'admin_unban_user':
            try:
                await query.answer()
            except:
                pass
            data['state'] = 'waiting_unban_user_id'
            try:
                await query.edit_message_text(
                    '<blockquote><b>أرسل آيدي العضو الذي تريد إلغاء حظره</b></blockquote>',
                    parse_mode='HTML'
                )
            except:
                pass
        
        elif query.data == 'admin_toggle_notifications':
            global join_notifications
            join_notifications = not join_notifications
            save_data()
            status = 'مفعل' if join_notifications else 'معطل'
            try:
                await query.answer(f'إشعار الدخول: {status}', show_alert=True)
            except:
                pass
        
        elif query.data == 'admin_forced_channels':
            try:
                await query.answer()
            except:
                pass
            keyboard = [
                [InlineKeyboardButton("إضافة", callback_data='admin_add_forced_channel')],
                [InlineKeyboardButton("حذف", callback_data='admin_remove_forced_channel')],
                [InlineKeyboardButton("رجوع",callback_data='admin_back')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            channels_text = '<blockquote><b>إدارة القنوات الإجبارية</b></blockquote>\n\n'
            if forced_channels:
                for idx, ch in enumerate(forced_channels, 1):
                    channels_text += f'<blockquote><b>{idx}. {ch.get("title", "قناة")}</b></blockquote>\n'
            else:
                channels_text += '<blockquote><b>لا توجد قنوات إجبارية</b></blockquote>'
            
            try:
                await query.edit_message_text(
                    channels_text,
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
            except:
                pass
        
        elif query.data == 'admin_add_forced_channel':
            try:
                await query.answer()
            except:
                pass
            data['state'] = 'waiting_forced_channel'
            try:
                await query.edit_message_text(
                    '<b>أرسل يوزر القناة الإجبارية</b>\n'
                    '<blockquote>تأكد أن البوت مشرف في القناة</blockquote>',
                    parse_mode='HTML'
                )
            except:
                pass
        
        elif query.data == 'admin_remove_forced_channel':
            if not forced_channels:
                try:
                    await query.answer('لا توجد قنوات إجبارية', show_alert=True)
                except:
                    pass
                return
            
            keyboard = []
            for idx, ch in enumerate(forced_channels):
                keyboard.append([InlineKeyboardButton(f"حذف {ch.get('title', 'قناة')}", callback_data=f'admin_remove_fc_{idx}')])
            
            keyboard.append([InlineKeyboardButton("رجوع", callback_data='admin_forced_channels')])
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            try:
                await query.edit_message_text(
                    '<blockquote><b>اختر القناة التي تريد حذفها</b></blockquote>',
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
            except:
                pass
        
        elif query.data.startswith('admin_remove_fc_'):
            idx = int(query.data.replace('admin_remove_fc_', ''))
            if 0 <= idx < len(forced_channels):
                removed_channel = forced_channels.pop(idx)
                save_data()
                try:
                    await query.answer(f'تم حذف {removed_channel.get("title", "القناة")}', show_alert=True)
                except:
                    pass
                
                keyboard = [[InlineKeyboardButton("رجوع", callback_data='admin_forced_channels')]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                try:
                    await query.edit_message_text(
                        '<blockquote><b>تم حذف القناة بنجاح</b></blockquote>',
                        reply_markup=reply_markup,
                        parse_mode='HTML'
                    )
                except:
                    pass
        
        elif query.data == 'admin_bot_control':
            global bot_active
            bot_active = not bot_active
            save_data()
            status = 'مفعل' if bot_active else 'معطل'
            try:
                await query.answer(f'البوت الآن: {status}', show_alert=True)
            except:
                pass
        
        elif query.data == 'admin_clear_banned':
            blocked_users.clear()
            save_data()
            try:
                await query.answer('تم مسح جميع المحظورين', show_alert=True)
            except:
                pass
        
        elif query.data == 'admin_back':
            try:
                await query.answer()
            except:
                pass
            admin_keyboard = [
                [InlineKeyboardButton("تعيين قناة السحوبات", callback_data='admin_set_broadcast_channel')],
                [
                    InlineKeyboardButton("إذاعة", callback_data='admin_broadcast'),
                    InlineKeyboardButton("الإحصائيات", callback_data='admin_stats')
                ],
                [
                    InlineKeyboardButton("حظر عضو", callback_data='admin_ban_user'),
                    InlineKeyboardButton("إلغاء حظر عضو", callback_data='admin_unban_user')
                ],
                [
                    InlineKeyboardButton("إشعار دخول", callback_data='admin_toggle_notifications'),
                    InlineKeyboardButton("اشتراك اجباري", callback_data='admin_forced_channels')
                ],
                [
                    InlineKeyboardButton("تحكم البوت", callback_data='admin_bot_control'),
                    InlineKeyboardButton("مسح المحظورين", callback_data='admin_clear_banned')
                ]
            ]
            admin_reply_markup = InlineKeyboardMarkup(admin_keyboard)
            
            try:
                await query.edit_message_text(
                    '<blockquote><b>لوحة تحكم الأدمن</b></blockquote>',
                    reply_markup=admin_reply_markup,
                    parse_mode='HTML'
                )
            except:
                pass

async def build_roulette_message(roulette, roulette_id):
    """بناء رسالة الروليت مع جميع الشروط"""
    roulette_text = f'<b>{roulette.get("template", "")}</b>\n\n'
    
    # إضافة الشروط إذا كانت موجودة
    has_conditions = False
    conditions_list = []
    
    if roulette.get('mandatory_channel'):
        has_conditions = True
        mandatory_username = roulette['mandatory_channel']
        conditions_list.append(f'الاشتراك في قناة ↞ @{mandatory_username}')
    
    if roulette.get('boost_channel'):
        has_conditions = True
        boost_username = roulette['boost_channel']
        conditions_list.append(f'يَجب تعزيز القناة ↞ @{boost_username}')
    
    if roulette.get('triple_username_required'):
        has_conditions = True
        conditions_list.append('أن يكون يوزرك ثلاثي مثل #_#_#')
    
    if roulette.get('premium_required'):
        has_conditions = True
        conditions_list.append('يَجب ان يكون في حسابك اشتراك مميز')
    
    if has_conditions:
        roulette_text += '<b>للمُشاركة تحتاج الى:</b>\n'
        for condition in conditions_list:
            roulette_text += f'<blockquote><b>{condition}</b></blockquote>\n'
        roulette_text += '\n'
    
    # إضافة معلومة السحب التلقائي
    if roulette.get('auto_draw_enabled'):
        auto_draw_count = roulette.get('auto_draw_count', 0)
        roulette_text += f'<blockquote><b>يُسحب تلقائيًا عند وصول {auto_draw_count} مشارك.</b></blockquote>\n'
    
    roulette_text += f'{get_footer_text()}'
    
    return roulette_text

async def perform_draw(context, roulette_id, roulette, auto_draw=False):
    """تنفيذ عملية السحب"""
    try:
        participants = participant_data.get(roulette_id, [])
        winners_count = roulette.get('winners_count', 1)
        
        # التحقق من وجود لاعبين على الأقل
        if len(participants) < 2:
            channel_id = roulette.get('channel_id')
            await context.bot.send_message(
                chat_id=channel_id,
                text='<blockquote><b>❌ يجب أن يكون هناك على الأقل لاعبين للبدء بالسحب</b></blockquote>',
                parse_mode='HTML'
            )
            return False
        
        # إيقاف المشاركة تلقائياً إذا كان السحب تلقائي
        if auto_draw and roulette.get('active', True):
            roulette['active'] = False
            roulette_status[roulette_id] = False
            save_data()
            await update_participants_count(context, roulette_id)
        
        if len(participants) < winners_count:
            winners_count = len(participants)
        
        channel_id = roulette.get('channel_id')
        
        await context.bot.send_message(
            chat_id=channel_id,
            text='<b>سَوف يتم ألسحب الان</b>',
            parse_mode='HTML'
        )
        
        await asyncio.sleep(10)
        
        winners = random.sample(participants, winners_count)
        
        result_text = '<b>الفائزين في السحب</b>\n'
        
        for idx, winner in enumerate(winners, 1):
            winner_link = f'<a href="tg://user?id={winner["user_id"]}">{winner["first_name"]}</a>'
            result_text += f'<blockquote><b>{idx}. {winner_link}</b></blockquote>\n'
        
        result_text += f'\n{get_footer_text()}'
        
        keyboard = [[InlineKeyboardButton("سحَب فائز أخر", callback_data=f'draw_another_{roulette_id}')]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.send_message(
            chat_id=channel_id,
            text=result_text,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        
        # إرسال رسالة إضافية إن وجدت
        if roulette.get('win_message'):
            await asyncio.sleep(2)
            await context.bot.send_message(
                chat_id=channel_id,
                text=f'<b>{roulette["win_message"]}</b>',
                parse_mode='HTML'
            )
        
        # حذف الفائزين من قائمة المشاركين
        for winner in winners:
            participant_data[roulette_id] = [p for p in participant_data[roulette_id] if p['user_id'] != winner['user_id']]
            
            # تحديث إحصائيات الفائز
            update_user_stats(winner['user_id'], 'wins', 1)
        
        save_data()
        
        for winner in winners:
            if winner['user_id'] in reminder_users:
                try:
                    channel_username = 'القناة'
                    for ch in get_user_data(roulette['owner_id'])['channels']:
                        if str(ch.get('id')) == str(channel_id):
                            channel_username = f"@{ch.get('username', 'القناة')}"
                            break
                    
                    win_text = '<blockquote><b>مبروك لقد فزت بجائزة السحب</b></blockquote>\n'
                    win_text += f'<b>في قناة {channel_username}</b>'
                    
                    await context.bot.send_message(
                        chat_id=winner['user_id'],
                        text=win_text,
                        parse_mode='HTML'
                    )
                except Exception as e:
                    logger.error(f'Error sending win notification: {e}')
        
        return True
        
    except Exception as e:
        logger.error(f'Error in draw: {e}')
        return False


async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    data = get_user_data(user_id)
    
    # معالجة أوامر الأدمن
    if user_id == ADMIN_ID:
        if data['state'] == 'waiting_broadcast_channel':
            channel_input = update.message.text.strip().replace('@', '').replace('https://t.me/', '')
            
            try:
                chat = await context.bot.get_chat(f'@{channel_input}')
                
                bot_member = await context.bot.get_chat_member(f'@{channel_input}', context.bot.id)
                
                if bot_member.status not in ['administrator', 'creator']:
                    await update.message.reply_text(
                        '<blockquote><b>البوت ليس مشرف في القناة، الرجاء رفع البوت مشرف</b></blockquote>',
                        parse_mode='HTML'
                    )
                    return
                
                global broadcast_channel_id, broadcast_channel_username
                broadcast_channel_id = str(chat.id)
                broadcast_channel_username = chat.username or channel_input
                save_data()
                
                data['state'] = None
                
                await update.message.reply_text(
                    f'<blockquote><b>تم تعيين قناة السحوبات: {chat.title}</b></blockquote>',
                    parse_mode='HTML'
                )
                
            except Exception as e:
                logger.error(f'Error setting broadcast channel: {e}')
                await update.message.reply_text(
                    '<blockquote><b>حدث خطأ، تأكد من صحة اليوزر وأن البوت مشرف في القناة</b></blockquote>',
                    parse_mode='HTML'
                )
            return
        
        elif data['state'] == 'waiting_broadcast_message':
            broadcast_message = update.message.text
            data['state'] = None
            
            success_count = 0
            fail_count = 0
            
            await update.message.reply_text(
                '<blockquote><b>جاري إرسال الإذاعة...</b></blockquote>',
                parse_mode='HTML'
            )
            
            for uid in all_users:
                if uid not in blocked_users:
                    try:
                        await context.bot.send_message(
                            chat_id=uid,
                            text=broadcast_message,
                            parse_mode='HTML'
                        )
                        success_count += 1
                        await asyncio.sleep(0.05)
                    except Exception as e:
                        fail_count += 1
                        logger.error(f'Error broadcasting to {uid}: {e}')
            
            await update.message.reply_text(
                f'<blockquote><b>تم إرسال الإذاعة</b></blockquote>\n'
                f'<blockquote><b>نجح: {success_count}</b></blockquote>\n'
                f'<blockquote><b>فشل: {fail_count}</b></blockquote>',
                parse_mode='HTML'
            )
            return
        
        elif data['state'] == 'waiting_ban_user_id':
            try:
                ban_user_id = int(update.message.text.strip())
                
                if ban_user_id == ADMIN_ID:
                    await update.message.reply_text(
                        '<blockquote><b>لا يمكنك حظر نفسك</b></blockquote>',
                        parse_mode='HTML'
                    )
                    return
                
                blocked_users.add(ban_user_id)
                save_data()
                data['state'] = None
                
                try:
                    keyboard = [[InlineKeyboardButton("المطور", url=f'tg://user?id={ADMIN_ID}')]]
                    reply_markup = InlineKeyboardMarkup(keyboard)
                    
                    await context.bot.send_message(
                        chat_id=ban_user_id,
                        text='<blockquote><b>تم حظرك من استخدام البوت</b></blockquote>',
                        reply_markup=reply_markup,
                        parse_mode='HTML'
                    )
                except:
                    pass
                
                await update.message.reply_text(
                    '<blockquote><b>تم حظر المستخدم بنجاح</b></blockquote>',
                    parse_mode='HTML'
                )
                
            except ValueError:
                await update.message.reply_text(
                    '<blockquote><b>الرجاء إرسال رقم صحيح (آيدي المستخدم)</b></blockquote>',
                    parse_mode='HTML'
                )
            return
        
        elif data['state'] == 'waiting_unban_user_id':
            try:
                unban_user_id = int(update.message.text.strip())
                
                if unban_user_id in blocked_users:
                    blocked_users.remove(unban_user_id)
                    save_data()
                    data['state'] = None
                    
                    try:
                        await context.bot.send_message(
                            chat_id=unban_user_id,
                            text='<blockquote><b>تم رفع حظرك من استخدام البوت</b></blockquote>',
                            parse_mode='HTML'
                        )
                    except:
                        pass
                    
                    await update.message.reply_text(
                        '<blockquote><b>تم إلغاء حظر المستخدم بنجاح</b></blockquote>',
                        parse_mode='HTML'
                    )
                else:
                    await update.message.reply_text(
                        '<blockquote><b>هذا المستخدم غير محظور</b></blockquote>',
                        parse_mode='HTML'
                    )
                
            except ValueError:
                await update.message.reply_text(
                    '<blockquote><b>الرجاء إرسال رقم صحيح (آيدي المستخدم)</b></blockquote>',
                    parse_mode='HTML'
                )
            return
        
        elif data['state'] == 'waiting_forced_channel':
            channel_input = update.message.text.strip().replace('@', '').replace('https://t.me/', '')
            
            try:
                chat = await context.bot.get_chat(f'@{channel_input}')
                
                bot_member = await context.bot.get_chat_member(f'@{channel_input}', context.bot.id)
                
                if bot_member.status not in ['administrator', 'creator']:
                    await update.message.reply_text(
                        '<blockquote><b>البوت ليس مشرف في القناة، الرجاء رفع البوت مشرف</b></blockquote>',
                        parse_mode='HTML'
                    )
                    return
                
                channel_info = {
                    'id': str(chat.id),
                    'title': chat.title,
                    'username': chat.username or channel_input
                }
                
                if not any(ch.get('id') == str(chat.id) for ch in forced_channels):
                    forced_channels.append(channel_info)
                    save_data()
                
                data['state'] = None
                
                await update.message.reply_text(
                    f'<blockquote><b>تم إضافة القناة الإجبارية: {chat.title}</b></blockquote>',
                    parse_mode='HTML'
                )
                
            except Exception as e:
                logger.error(f'Error adding forced channel: {e}')
                await update.message.reply_text(
                    '<blockquote><b>حدث خطأ، تأكد من صحة اليوزر وأن البوت مشرف في القناة</b></blockquote>',
                    parse_mode='HTML'
                )
            return
    
    # التحقق من الحظر
    if user_id in blocked_users:
        return
    
    # معالجة باقي الحالات للمستخدمين العاديين
    if data['state'] == 'waiting_channel_username':
        channel_username = update.message.text.strip().replace('@', '')
        
        try:
            chat = await context.bot.get_chat(f'@{channel_username}')
            
            bot_member = await context.bot.get_chat_member(f'@{channel_username}', context.bot.id)
            
            if bot_member.status not in ['administrator', 'creator']:
                await update.message.reply_text(
                    '<blockquote><b>البوت ليس مشرف في القناة، الرجاء رفع البوت مشرف</b></blockquote>',
                    parse_mode='HTML'
                )
                return
            
            # التحقق من أن المستخدم أدمن في القناة
            is_admin = await check_user_is_admin(context, channel_username, user_id)
            if not is_admin:
                await update.message.reply_text(
                    f'<b><u>❗ يجب أن تكون أدمن أو مالك في القناة لإنشاء سحب</u></b>\n\n'
                    f'<b>القناة: @{channel_username}</b>',
                    parse_mode='HTML'
                )
                return
            
            channel_info = {
                'id': str(chat.id),
                'title': chat.title,
                'username': chat.username or channel_username,
                'type': chat.type
            }
            
            already_exists = False
            for ch in data['channels']:
                if str(ch.get('id')) == str(chat.id):
                    already_exists = True
                    break
            
            if not already_exists:
                data['channels'].append(channel_info)
                save_data()
            
            data['state'] = None
            
            keyboard = [[InlineKeyboardButton("رجوع", callback_data='manage_channels')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                '<blockquote><b>تم إضافة القناة بنجاح</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            
        except Exception as e:
            logger.error(f'Error adding channel: {e}')
            await update.message.reply_text(
                '<blockquote><b>حدث خطأ، تأكد من صحة اليوزر وأن البوت مشرف في القناة</b></blockquote>',
                parse_mode='HTML'
            )
    
    elif data['state'] == 'waiting_private_channel':
        channel_link = update.message.text.strip()
        
        # استخراج معرف القناة من الرابط
        try:
            # يمكن أن يكون رابط مثل https://t.me/+xxxxx
            if '/+' in channel_link or 'joinchat' in channel_link:
                await update.message.reply_text(
                    '<blockquote><b>للقنوات الخاصة، قم بإضافة البوت كمشرف ثم أرسل أي رسالة من القناة إلى البوت</b></blockquote>',
                    parse_mode='HTML'
                )
                return
            
            data['state'] = None
            
            keyboard = [[InlineKeyboardButton("رجوع", callback_data='manage_channels')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                '<blockquote><b>تم إضافة القناة الخاصة، تأكد أن البوت مشرف فيها</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        except Exception as e:
            logger.error(f'Error adding private channel: {e}')
            await update.message.reply_text(
                '<blockquote><b>حدث خطأ في إضافة القناة الخاصة</b></blockquote>',
                parse_mode='HTML'
            )
    
    elif data['state'] == 'waiting_template':
        template_text = update.message.text
        data['temp_data']['template'] = template_text
        data['state'] = None
        
        keyboard = [
            [InlineKeyboardButton("أضف قناة اجباري", callback_data='add_mandatory_channel')],
            [InlineKeyboardButton("أضف شرط تعزيز القناة", callback_data='add_boost_requirement')],
            [InlineKeyboardButton("أضف شرط يوزر ثلاثي", callback_data='add_triple_username')],
            [InlineKeyboardButton("أضف المستخدمين المميزين", callback_data='add_premium_requirement')],
            [InlineKeyboardButton("اضافة السحب التلقائي", callback_data='add_auto_draw')],
            [InlineKeyboardButton("حفظ ألاعدادات", callback_data='save_settings')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            '<blockquote><b>تم حفظ الكليشة ألان اختار شيء من الاعدادات السحب</b></blockquote>',
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
    
    elif data['state'] == 'waiting_mandatory_channel':
        mandatory_channel_link = update.message.text.strip()
        
        try:
            channel_username = mandatory_channel_link.split('/')[-1].replace('@', '')
            
            chat = await context.bot.get_chat(f'@{channel_username}')
            
            bot_member = await context.bot.get_chat_member(f'@{channel_username}', context.bot.id)
            
            if bot_member.status not in ['administrator', 'creator']:
                await update.message.reply_text(
                    '<blockquote><b>البوت ليس مشرف في القناة، الرجاء رفع البوت مشرف</b></blockquote>',
                    parse_mode='HTML'
                )
                return
            
            # التحقق من أن المستخدم أدمن في القناة
            is_admin = await check_user_is_admin(context, channel_username, user_id)
            if not is_admin:
                await update.message.reply_text(
                    f'<b><u>❗ يجب أن تكون أدمن أو مالك في القناة لإنشاء سحب</u></b>\n\n'
                    f'<b>القناة: @{channel_username}</b>',
                    parse_mode='HTML'
                )
                return
            
            data['temp_data']['mandatory_channel'] = channel_username
            data['temp_data']['mandatory_channel_id'] = str(chat.id)
            data['temp_data']['mandatory_channel_title'] = chat.title
            data['state'] = None
            
            keyboard = [[InlineKeyboardButton("رجوع", callback_data='settings_menu')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                '<blockquote><b>تم اضافة القناة الاجباري</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            
        except Exception as e:
            logger.error(f'Error adding mandatory channel: {e}')
            await update.message.reply_text(
                '<blockquote><b>حدث خطأ، تأكد من صحة الرابط وأن البوت مشرف في القناة</b></blockquote>',
                parse_mode='HTML'
            )
    
    elif data['state'] == 'waiting_boost_channel':
        boost_channel_link = update.message.text.strip()
        
        try:
            channel_username = boost_channel_link.split('/')[-1].replace('@', '')
            
            chat = await context.bot.get_chat(f'@{channel_username}')
            
            bot_member = await context.bot.get_chat_member(f'@{channel_username}', context.bot.id)
            
            if bot_member.status not in ['administrator', 'creator']:
                await update.message.reply_text(
                    '<blockquote><b>البوت ليس مشرف في القناة، الرجاء رفع البوت مشرف</b></blockquote>',
                    parse_mode='HTML'
                )
                return
            
            # التحقق من أن المستخدم أدمن في القناة
            is_admin = await check_user_is_admin(context, channel_username, user_id)
            if not is_admin:
                await update.message.reply_text(
                    f'<b><u>❗ يجب أن تكون أدمن أو مالك في القناة لإنشاء سحب</u></b>\n\n'
                    f'<b>القناة: @{channel_username}</b>',
                    parse_mode='HTML'
                )
                return
            
            data['temp_data']['boost_channel'] = channel_username
            data['temp_data']['boost_channel_id'] = str(chat.id)
            data['temp_data']['boost_channel_title'] = chat.title
            data['state'] = None
            
            keyboard = [[InlineKeyboardButton("رجوع", callback_data='settings_menu')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                '<blockquote><b>تم اضافة قناة التعزيز</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            
        except Exception as e:
            logger.error(f'Error adding boost channel: {e}')
            await update.message.reply_text(
                '<blockquote><b>حدث خطأ، تأكد من صحة الرابط وأن البوت مشرف في القناة</b></blockquote>',
                parse_mode='HTML'
            )
    
    elif data['state'] == 'waiting_auto_draw_count':
        try:
            auto_draw_count = int(update.message.text.strip())
            
            if auto_draw_count <= 0:
                await update.message.reply_text(
                    '<blockquote><b>الرجاء إدخال رقم صحيح أكبر من صفر</b></blockquote>',
                    parse_mode='HTML'
                )
                return
            
            data['temp_data']['auto_draw_enabled'] = True
            data['temp_data']['auto_draw_count'] = auto_draw_count
            data['state'] = None
            
            keyboard = [[InlineKeyboardButton("رجوع", callback_data='settings_menu')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                '<blockquote><b>تم حفظ الشرط</b></blockquote>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            
        except ValueError:
            await update.message.reply_text(
                '<blockquote><b>الرجاء ارسال رقم صحيح</b></blockquote>',
                parse_mode='HTML'
            )
    
    elif data['state'] == 'waiting_winners_count':
        try:
            winners_count = int(update.message.text.strip())
            
            if winners_count <= 0:
                await update.message.reply_text(
                    '<blockquote><b>الرجاء إدخال رقم صحيح أكبر من صفر</b></blockquote>',
                    parse_mode='HTML'
                )
                return
            
            data['temp_data']['winners_count'] = winners_count
            data['state'] = 'waiting_win_message'
            
            keyboard = [[InlineKeyboardButton("تخطي", callback_data='skip_win_message')]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                '<b>هل تريد أضافة رسَالة في القناة عندما الشخص يفوز</b>\n'
                '<b>مثل: راسلني لأستلام جائزك @xDevAli</b>\n\n'
                '<b>- يمكنك تخطي هذا الخطوة.</b>',
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            
        except ValueError:
            await update.message.reply_text(
                '<blockquote><b>الرجاء ارسال رقم صحيح</b></blockquote>',
                parse_mode='HTML'
            )
        except Exception as e:
            logger.error(f'Error in winners count: {e}')
            await update.message.reply_text(
                '<blockquote><b>حدث خطأ، الرجاء المحاولة مرة أخرى</b></blockquote>',
                parse_mode='HTML'
            )
    
    elif data['state'] == 'waiting_win_message':
        win_message = update.message.text.strip()
        data['temp_data']['win_message'] = win_message
        data['state'] = None
        
        # نشر الروليت مباشرة
        await publish_roulette(update, context, data)

async def publish_roulette(update, context, data):
    """نشر الروليت في القناة"""
    user_id = update.effective_user.id
    
    channel_id = data['temp_data'].get('selected_channel')
    channel_username = None
    channel_title = None
    
    for channel in data['channels']:
        if str(channel.get('id')) == str(channel_id):
            channel_username = channel.get('username', 'channel')
            channel_title = channel.get('title', 'القناة')
            break
    
    if not channel_username:
        await update.message.reply_text(
            '<blockquote><b>حدث خطأ في العثور على القناة</b></blockquote>',
            parse_mode='HTML'
        )
        return
    
    roulette_id = f"roulette_{user_id}_{random.randint(10000, 99999)}_{int(datetime.now().timestamp())}"
    
    roulette_data[roulette_id] = {
        'owner_id': user_id,
        'channel_id': channel_id,
        'channel_username': channel_username,
        'channel_title': channel_title,
        'template': data['temp_data'].get('template', ''),
        'roulette_type': data['temp_data'].get('roulette_type', 'normal'),
        'mandatory_channel': data['temp_data'].get('mandatory_channel'),
        'mandatory_channel_id': data['temp_data'].get('mandatory_channel_id'),
        'mandatory_channel_title': data['temp_data'].get('mandatory_channel_title'),
        'boost_channel': data['temp_data'].get('boost_channel'),
        'boost_channel_id': data['temp_data'].get('boost_channel_id'),
        'boost_channel_title': data['temp_data'].get('boost_channel_title'),
        'triple_username_required': data['temp_data'].get('triple_username_required', False),
        'premium_required': data['temp_data'].get('premium_required', False),
        'auto_draw_enabled': data['temp_data'].get('auto_draw_enabled', False),
        'auto_draw_count': data['temp_data'].get('auto_draw_count', 0),
        'winners_count': data['temp_data'].get('winners_count', 1),
        'win_message': data['temp_data'].get('win_message'),
        'active': True,
        'created_at': datetime.now()
    }
    
    participant_data[roulette_id] = []
    roulette_status[roulette_id] = True
    
    # تحديث إحصائيات المستخدم
    update_user_stats(user_id, 'created_giveaways', 1)
    
    save_data()
    
    await update.message.reply_text(
        f'<blockquote><b>تم نشر الروليت في القناة @{channel_username}</b></blockquote>',
        parse_mode='HTML'
    )
    
    roulette_text = await build_roulette_message(roulette_data[roulette_id], roulette_id)
    
    participants_count = 0
    join_url = f'https://t.me/{BOT_USERNAME}?start=join_{roulette_id}'
    withdraw_url = f'https://t.me/{BOT_USERNAME}?start=withdraw_{roulette_id}'
    share_url = f'https://t.me/share/url?url={join_url}'
    
    keyboard = [
        [InlineKeyboardButton(f"أنَضمام [{participants_count}]", url=join_url)],
        [InlineKeyboardButton("إنسَحاب", url=withdraw_url)],
        [
            InlineKeyboardButton("بَدأ السَحب", callback_data=f'draw_roulette_{roulette_id}'),
            InlineKeyboardButton("أوقف المُشاركة", callback_data=f'stop_participation_{roulette_id}')
        ],
        [InlineKeyboardButton("تَصفيه المُغادرين", callback_data=f'filter_left_{roulette_id}')],
        [InlineKeyboardButton("ذَكرني إذا فزت", url=f'https://t.me/{BOT_USERNAME}?start=win')],
        [
            InlineKeyboardButton("مشاركة السحب", url=share_url),
            InlineKeyboardButton("إعادة النشر", callback_data=f'republish_{roulette_id}')
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        sent_message = await context.bot.send_message(
            chat_id=channel_id,
            text=roulette_text,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        
        roulette_data[roulette_id]['message_id'] = sent_message.message_id
        
        # رابط المنشور
        post_url = f'https://t.me/{channel_username}/{sent_message.message_id}'
        roulette_data[roulette_id]['post_url'] = post_url
        
        save_data()
        
        # إشعار قناة السحوبات
        if broadcast_channel_id:
            try:
                broadcast_text = '<blockquote><b>تم انشاء سحب جديد</b></blockquote>\n\n'
                broadcast_text += f'<blockquote><b>{data["temp_data"].get("template", "")}</b></blockquote>\n\n'
                
                channel_link_text = f'<a href="https://t.me/{channel_username}">{channel_title}</a>'
                broadcast_text += f'<blockquote><b>قناة السحب: {channel_link_text}</b></blockquote>'
                
                broadcast_keyboard = [[InlineKeyboardButton("رابط السحب", url=post_url)]]
                broadcast_reply_markup = InlineKeyboardMarkup(broadcast_keyboard)
                
                await context.bot.send_message(
                    chat_id=broadcast_channel_id,
                    text=broadcast_text,
                    reply_markup=broadcast_reply_markup,
                    parse_mode='HTML'
                )
            except Exception as e:
                logger.error(f'Error broadcasting to channel: {e}')
        
    except Exception as e:
        logger.error(f'Error sending roulette message: {e}')
        await update.message.reply_text(
            '<blockquote>حدث خطأ في نشر الروليت، تأكد أن البوت مشرف في القناة</blockquote>',
            parse_mode='HTML'
        )
    
    data['temp_data'] = {}
    save_data()

async def callback_skip_win_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة زر تخطي رسالة الفوز"""
    query = update.callback_query
    
    user_id = query.from_user.id
    data = get_user_data(user_id)
    
    if query.data == 'skip_win_message':
        try:
            await query.answer()
        except:
            pass
        data['state'] = None
        # نشر الروليت مباشرة
        await publish_roulette_from_callback(query, context, data)

async def publish_roulette_from_callback(query, context, data):
    """نشر الروليت من callback"""
    user_id = query.from_user.id
    
    channel_id = data['temp_data'].get('selected_channel')
    channel_username = None
    channel_title = None
    
    for channel in data['channels']:
        if str(channel.get('id')) == str(channel_id):
            channel_username = channel.get('username', 'channel')
            channel_title = channel.get('title', 'القناة')
            break
    
    if not channel_username:
        try:
            await query.edit_message_text(
                '<blockquote><b>حدث خطأ في العثور على القناة</b></blockquote>',
                parse_mode='HTML'
            )
        except:
            pass
        return
    
    roulette_id = f"roulette_{user_id}_{random.randint(10000, 99999)}_{int(datetime.now().timestamp())}"
    
    roulette_data[roulette_id] = {
        'owner_id': user_id,
        'channel_id': channel_id,
        'channel_username': channel_username,
        'channel_title': channel_title,
        'template': data['temp_data'].get('template', ''),
        'roulette_type': data['temp_data'].get('roulette_type', 'normal'),
        'mandatory_channel': data['temp_data'].get('mandatory_channel'),
        'mandatory_channel_id': data['temp_data'].get('mandatory_channel_id'),
        'mandatory_channel_title': data['temp_data'].get('mandatory_channel_title'),
        'boost_channel': data['temp_data'].get('boost_channel'),
        'boost_channel_id': data['temp_data'].get('boost_channel_id'),
        'boost_channel_title': data['temp_data'].get('boost_channel_title'),
        'triple_username_required': data['temp_data'].get('triple_username_required', False),
        'premium_required': data['temp_data'].get('premium_required', False),
        'auto_draw_enabled': data['temp_data'].get('auto_draw_enabled', False),
        'auto_draw_count': data['temp_data'].get('auto_draw_count', 0),
        'winners_count': data['temp_data'].get('winners_count', 1),
        'win_message': data['temp_data'].get('win_message'),
        'active': True,
        'created_at': datetime.now()
    }
    
    participant_data[roulette_id] = []
    roulette_status[roulette_id] = True
    
    # تحديث إحصائيات المستخدم
    update_user_stats(user_id, 'created_giveaways', 1)
    
    save_data()
    
    try:
        await query.edit_message_text(
            f'<blockquote><b>تم نشر الروليت في القناة @{channel_username}</b></blockquote>',
            parse_mode='HTML'
        )
    except:
        pass
    
    roulette_text = await build_roulette_message(roulette_data[roulette_id], roulette_id)
    
    participants_count = 0
    join_url = f'https://t.me/{BOT_USERNAME}?start=join_{roulette_id}'
    withdraw_url = f'https://t.me/{BOT_USERNAME}?start=withdraw_{roulette_id}'
    share_url = f'https://t.me/share/url?url={join_url}'
    
    keyboard = [
        [InlineKeyboardButton(f"أنَضمام [{participants_count}]", url=join_url)],
        [InlineKeyboardButton("إنسَحاب", url=withdraw_url)],
        [
            InlineKeyboardButton("بَدأ السَحب", callback_data=f'draw_roulette_{roulette_id}'),
            InlineKeyboardButton("أوقف المُشاركة", callback_data=f'stop_participation_{roulette_id}')
        ],
        [InlineKeyboardButton("تَصفيه المُغادرين", callback_data=f'filter_left_{roulette_id}')],
        [InlineKeyboardButton("ذَكرني إذا فزت", url=f'https://t.me/{BOT_USERNAME}?start=win')],
        [
            InlineKeyboardButton("مشاركة السحب", url=share_url),
            InlineKeyboardButton("إعادة النشر", callback_data=f'republish_{roulette_id}')
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    try:
        sent_message = await context.bot.send_message(
            chat_id=channel_id,
            text=roulette_text,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        
        roulette_data[roulette_id]['message_id'] = sent_message.message_id
        
        # رابط المنشور
        post_url = f'https://t.me/{channel_username}/{sent_message.message_id}'
        roulette_data[roulette_id]['post_url'] = post_url
        
        save_data()
        
        # إشعار قناة السحوبات
        if broadcast_channel_id:
            try:
                broadcast_text = '<blockquote><b>تم انشاء سحب جديد</b></blockquote>\n\n'
                broadcast_text += f'<blockquote><b>{data["temp_data"].get("template", "")}</b></blockquote>\n\n'
                
                channel_link_text = f'<a href="https://t.me/{channel_username}">{channel_title}</a>'
                broadcast_text += f'<blockquote><b>قناة السحب: {channel_link_text}</b></blockquote>'
                
                broadcast_keyboard = [[InlineKeyboardButton("رابط السحب", url=post_url)]]
                broadcast_reply_markup = InlineKeyboardMarkup(broadcast_keyboard)
                
                await context.bot.send_message(
                    chat_id=broadcast_channel_id,
                    text=broadcast_text,
                    reply_markup=broadcast_reply_markup,
                    parse_mode='HTML'
                )
            except Exception as e:
                logger.error(f'Error broadcasting to channel: {e}')
        
    except Exception as e:
        logger.error(f'Error sending roulette message: {e}')
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text='<blockquote>حدث خطأ في نشر الروليت، تأكد أن البوت مشرف في القناة</blockquote>',
                parse_mode='HTML'
            )
        except:
            pass
    
    data['temp_data'] = {}
    save_data()

async def update_participants_count(context: ContextTypes.DEFAULT_TYPE, roulette_id: str):
    try:
        roulette = roulette_data.get(roulette_id)
        if not roulette:
            return
        
        channel_id = roulette.get('channel_id')
        message_id = roulette.get('message_id')
        
        if not channel_id or not message_id:
            return
        
        participants = participant_data.get(roulette_id, [])
        participants_count = len(participants)
        
        channel_username = roulette.get('channel_username', 'channel')
        
        roulette_text = await build_roulette_message(roulette, roulette_id)
        
        join_url = f'https://t.me/{BOT_USERNAME}?start=join_{roulette_id}'
        withdraw_url = f'https://t.me/{BOT_USERNAME}?start=withdraw_{roulette_id}'
        share_url = f'https://t.me/share/url?url={join_url}'
        
        is_active = roulette.get('active', True)
        
        if is_active:
            keyboard = [
                [InlineKeyboardButton(f"أنَضمام [{participants_count}]", url=join_url)],
                [InlineKeyboardButton("إنسَحاب", url=withdraw_url)],
                [
                    InlineKeyboardButton("بَدأ السَحب", callback_data=f'draw_roulette_{roulette_id}'),
                    InlineKeyboardButton("أوقف المُشاركة", callback_data=f'stop_participation_{roulette_id}')
                ],
                [InlineKeyboardButton("تَصفيه المُغادرين", callback_data=f'filter_left_{roulette_id}')],
                [InlineKeyboardButton("ذَكرني إذا فزت", url=f'https://t.me/{BOT_USERNAME}?start=win')],
                [
                    InlineKeyboardButton("مشاركة السحب", url=share_url),
                    InlineKeyboardButton("إعادة النشر", callback_data=f'republish_{roulette_id}')
                ]
            ]
        else:
            keyboard = [
                [InlineKeyboardButton(f"أنَضمام [{participants_count}]", url=join_url)],
                [InlineKeyboardButton("إنسَحاب", url=withdraw_url)],
                [
                    InlineKeyboardButton("بَدأ السَحب", callback_data=f'draw_roulette_{roulette_id}'),
                    InlineKeyboardButton("تفعيل المُشاركة", callback_data=f'activate_participation_{roulette_id}')
                ],
                [InlineKeyboardButton("تَصفيه المُغادرين", callback_data=f'filter_left_{roulette_id}')],
                [InlineKeyboardButton("ذَكرني إذا فزت", url=f'https://t.me/{BOT_USERNAME}?start=win')],
                [
                    InlineKeyboardButton("مشاركة السحب", url=share_url),
                    InlineKeyboardButton("إعادة النشر", callback_data=f'republish_{roulette_id}')
                ]
            ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await context.bot.edit_message_text(
            chat_id=channel_id,
            message_id=message_id,
            text=roulette_text,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        
    except Exception as e:
        logger.error(f'Error updating participants count: {e}')

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f'Update {update} caused error {context.error}')

def main():
    load_data()
    
    application = Application.builder().token(TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(callback_skip_win_message, pattern='^skip_win_message$'))
    application.add_handler(CallbackQueryHandler(button_callback))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    
    application.add_error_handler(error_handler)
    
    logger.info('Bot started successfully')
    
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
    